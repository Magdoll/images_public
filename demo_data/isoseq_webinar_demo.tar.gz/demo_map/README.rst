# ##################################
# -- getting non-redundant transcripts using genome mapping
#
# (1) mapping to hg19 using GMAP
# (2) sort GMAP SAM file
# (3) run collapse, don't merge 5'
# (4) run collapse, merge 5'
# ##################################
~/bin/gmap -D ~/share/gmap_db_new/ -d hg19 -f samse -n 0 -t 24 demo.quivered_hq.fastq > demo.quivered_hq.fastq.sam 2> demo.quivered_hq.fastq.sam.log
sort -k 3,3 -k 4,4n demo.quivered_hq.fastq.sam > demo.quivered_hq.fastq.sorted.sam

collapse_isoforms_by_sam.py --input demo.quivered_hq.fastq --fq -s demo.quivered_hq.fastq.sorted.sam --dun-merge-5-shorter -o demo.no5merge
collapse_isoforms_by_sam.py --input demo.quivered_hq.fastq --fq -s demo.quivered_hq.fastq.sorted.sam -o demo.5merge

# ##################################
# -- using MatchAnnot to compare against reference transcript annotations
#
# (1) mapping to hg19 using GMAP (collapsed result)
# (2) sort GMAP SAM file
# (3) compare with Gencode hg19
# ##################################
~/bin/gmap -D ~/share/gmap_db_new/ -d hg19 -f samse -n 0 -t 24 demo.5merge.collapsed.rep.fq > demo.5merge.collapsed.rep.fq.sam
sort -k 3,3 -k 4,4n demo.5merge.collapsed.rep.fq.sam > demo.5merge.collapsed.rep.fq.sorted.sam

matchAnnot.py --gtf ~/share/gencode/gencode.v19.annotation.gtf demo.5merge.collapsed.rep.fq.sorted.sam > demo.5merge.collapsed.rep.fq.matchAnnot_report.txt


# ##################################
# -- finding fusion transcripts
#
# (1) run fusion_finder
# (2) mapping fusion candidates to hg19 using GMAP
# (3) sort GMAP SAM file
# (4) compare with Gencode hg19
# ##################################
fusion_finder.py --input demo.quivered_hq.fastq --fq -s demo.quivered_hq.fastq.sorted.sam -o demo.fusion

~/bin/gmap -D ~/share/gmap_db_new/ -d hg19 -f samse -n 0 -t 24 demo.fusion.rep.fq > demo.fusion.rep.fq.sam
sort -k 3,3 -k 4,4n demo.fusion.rep.fq.sam > demo.fusion.rep.fq.sorted.sam

matchAnnot.py --gtf ~/share/gencode/gencode.v19.annotation.gtf demo.fusion.rep.fq.sorted.sam > demo.fusion.matchAnnot_report.txt
